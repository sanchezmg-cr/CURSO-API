﻿namespace _06_Inventory.Api
{
    public class SettingsValue
    {
        public string ConnectionString { get; set; }
    }
}
