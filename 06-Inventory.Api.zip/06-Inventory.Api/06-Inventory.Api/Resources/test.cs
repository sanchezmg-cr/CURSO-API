﻿namespace _06_Inventory.Api.Resources
{
    public class test
    {
    }
}
